// Phạm Hoài Vũ - 21522804
export interface Fruit {
    onSelect: (selected: string[]) => void;
}
  