// Phạm Hoài Vũ - 21522804
export interface Workout {
    onSelect: (selected: string[]) => void;
}