const itemList = [
	{
		username: "HvuPham",
		title: "Hello",
		imgUrl:
			"https://i.pinimg.com/control/474x/67/76/c5/6776c56e89f1a6df32c00775b07845d8.jpg",
		likes: 24,
		comments: 50,
		shares: 250,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl:
			"https://i.pinimg.com/474x/bd/51/ea/bd51eade201d05259b4fb72ff3053540.jpg",
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl: "https://i.pinimg.com/474x/0d/e6/87/0de6879366b7276f8857ad64836794ca.jpg",
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hello",
		imgUrl: "https://i.pinimg.com/474x/5e/80/0a/5e800a947e87f35dd0be0ec0c5adf235.jpg",
		likes: 24,
		comments: 50,
		shares: 250,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl: 'https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg',
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl: 'https://i.pinimg.com/474x/5e/80/0a/5e800a947e87f35dd0be0ec0c5adf235.jpg',
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hello",
		imgUrl:
        'https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg',
        likes: 24,
		comments: 50,
		shares: 250,
	},
	
]
export default itemList;