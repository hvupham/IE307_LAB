// import * as SQLite from "expo-sqlite"
import * as SQLite from 'expo-sqlite/legacy';
export const db =  SQLite.openDatabase('ie307');
