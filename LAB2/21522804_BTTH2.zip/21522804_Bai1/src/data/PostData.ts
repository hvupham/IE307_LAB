// Phạm Hoài Vũ - 21522804
const itemList = [
	{
		username: "HvuPham",
		title: "i can do it!",
		imgUrl:
			"https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg",
		likes: 24,
		comments: 50,
		shares: 250,
	},
	{
		username: "HvuPham",
		title: "i got your back!",
		imgUrl:
			"https://i.pinimg.com/736x/d8/2d/b1/d82db192bfa37d3a0ca8594bf22f018f.jpg",
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl:
			"https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg",
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "i got your back",
		imgUrl:
			"https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg",
		likes: 24,
		comments: 50,
		shares: 250,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl:
			"https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg",
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hi mn~",
		imgUrl: 'https://i.pinimg.com/474x/5e/80/0a/5e800a947e87f35dd0be0ec0c5adf235.jpg',
		likes: 1000,
		comments: 200,
		shares: 50,
	},
	{
		username: "HvuPham",
		title: "Hello",
		imgUrl:
        'https://i.pinimg.com/474x/a9/b8/43/a9b843b45b13d393a22eca1b9f7fba1a.jpg',
        likes: 24,
		comments: 50,
		shares: 250,
	},
	
]
export default itemList;