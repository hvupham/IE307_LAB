// Phạm Hoài Vũ - 21522804
export interface status {
	LIKE: boolean
}