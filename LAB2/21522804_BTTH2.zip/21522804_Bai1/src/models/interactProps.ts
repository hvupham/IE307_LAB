// Phạm Hoài Vũ - 21522804
export interface interactProps {
	like: number
	comment: number
	share: number
}