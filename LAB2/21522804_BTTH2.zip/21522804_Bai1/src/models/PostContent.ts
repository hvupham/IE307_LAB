// Phạm Hoài Vũ - 21522804
export interface PostContentProps {
    title: string;
    imgUrl: string;
};