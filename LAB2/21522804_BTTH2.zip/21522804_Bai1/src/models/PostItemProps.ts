// Phạm Hoài Vũ - 21522804
export interface PostItemProps {
	username: string
	title: string
	imgUrl: string
	likes: number
	comments: number
	shares: number
}